#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <signal.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/wait.h>

#define MAX_CMD_STR 100
#define printftoflie(fp, format, ...)            \
	if(fp == NULL){printf(format, ##__VA_ARGS__);} 	\
	else{printf(format, ##__VA_ARGS__);	\
			fprintf(fp, format, ##__VA_ARGS__);fflush(fp);}
int sig_type = 0;
FILE *fp_res = NULL; 

int judgeres(int sig,int res,pid_t pid,int pin_h)
{
	if(sig==0){
		
		 if (res < 0)
        {
            printftoflie(fp_res, "[cli](%d) read pin_n return %d and errno is %d!\n", pid, res, errno);
            if (errno == EINTR)
            {
                if (sig_type == SIGINT)
                    return pin_h;
            }
            return pin_h;
        }
        if (res==0)
        {
            return pin_h;
        }
	}
	else if(sig==1)
	{
        if (res < 0)
        {
            printftoflie(fp_res, "[cli](%d) read len_n return %d and errno is %d\n", pid, res, errno);
            if (errno == EINTR)
            {
                if (sig_type == SIGINT)
                    return -1;
            }
            return -1;
        }
        else if (res == 0)
        {
            return -1;
        }
		
	}
	else
	{
		return 0;
	}
}

int echo_rqt(int sockfd, int pin)
{
    pid_t pid = getpid();
    int len_h = 0, len_n = 0;
    int pin_h = pin, pin_n = htonl(pin);
    char fn_td[10] = {0};
    char buf[MAX_CMD_STR + 1 + 8] = {0}; 
    int res = 0 ,sig=0;

    sprintf(fn_td, "td%d.txt", pin);
    FILE *fp_td = fopen(fn_td, "r");
    if (!fp_td)
    {
        printftoflie(fp_res, "[cli](%d) Test data read error!\n", pid);
        return 0;
    }

    while (fgets(buf + 8, MAX_CMD_STR, fp_td) != NULL)
    {
        pin_h = pin;
        pin_n = htonl(pin);
        if (strncmp(buf + 8, "exit", 4) == 0)
        {
            printf("[cli](%d) \"exit\" is found!\n", pid);
            break;
        }

        memcpy(buf, &pin_n, 4);
        len_h = strnlen(buf + 8, MAX_CMD_STR);
        len_n = htonl(len_h);
        memcpy(buf + 4, &len_n, 4);
        if (buf[len_h + 8 - 1] == '\n')
            buf[len_h + 8 - 1] = '\0';
        write(sockfd, buf, len_h + 8);
		
        res = read(sockfd, &pin_n, sizeof(pin_n));
        memset(buf, 0, sizeof(buf));
		
		sig=0;
		judgeres(sig,res,pid,pin_h);
		res = read(sockfd, &len_n, sizeof(len_n));
        pin_h = ntohl(pin_n);

		sig=1;
		judgeres(sig,res,pid,pin_h);
        
		int read_amnt = 0, len_to_read = len_h;
        memset(buf, 0, sizeof(buf));
        len_h = ntohl(len_n);

        while (1)
        {
            res = read(sockfd, buf + read_amnt, len_to_read);
            if (res <=0)
            {
                return -1;
            }

            read_amnt += res;
            if (read_amnt == len_h)
            {
                break;
            }
            else if (read_amnt < len_h)
            {
                len_to_read = len_h - read_amnt;
            }
            else
            {
                return -1;
            }
        }
        printftoflie(fp_res, "[echo_rep](%d) %s\n", pid, buf);
        memset(buf, 0, sizeof(buf));
    }
    return 0;
}

int main(int argc, char *argv[])
{
    if (argc != 4)
    {
        printf("Usage:%s <IP> <PORT> <CONCURRENT AMOUNT>\n", argv[0]);
        return 0;
    }


    struct sigaction sigact_chld, old_sigact_chld;
    sigact_chld.sa_handler = SIG_IGN;
    sigemptyset(&sigact_chld.sa_mask);
    sigact_chld.sa_flags = 0;
    sigact_chld.sa_flags |= SA_RESTART;
    sigaction(SIGCHLD, &sigact_chld, &old_sigact_chld);


    struct sockaddr_in srv_addr;
    struct sockaddr_in cli_addr;
    socklen_t cli_addr_len;
    int connfd;
    int conc_amnt = atoi(argv[3]);；
    pid_t pid = getpid();
    bzero(&srv_addr, sizeof(srv_addr));
    srv_addr.sin_family = AF_INET;
    inet_pton(AF_INET, argv[1], &srv_addr.sin_addr);
    srv_addr.sin_port = htons(atoi(argv[2]));

    for (int i = 0; i < conc_amnt - 1; i++)
    {
        if (!fork())
        {
            int pin = i + 1;
            char fn_res[20]; 
            pid_t pid = getpid();
            sprintf(fn_res, "stu_cli_res_%d.txt", pin);
            fp_res = fopen(fn_res, "ab"); 
            if (!fp_res)
            {
                printf("[cli](%d) child exits, failed to open file \"stu_cli_res_%d.txt\"!\n", pid, pin);
                exit(-1);
            }

            printf("[cli](%d) stu_cli_res_%d.txt is created!\n", pid, pin);
            printftoflie(fp_res, "[cli](%d) child process %d is created!\n", pid, pin);
            if ((connfd = socket(PF_INET, SOCK_STREAM, 0)) == -1)
                break;

            do
            {
                int res;
                res = connect(connfd, (struct sockaddr *)&srv_addr, sizeof(srv_addr));
                if (res == 0)
                {
                    char ip_str[20] = {0}; 
                    printftoflie(fp_res, "[cli](%d) server[%s:%d] is connected!\n", pid, inet_ntop(AF_INET, &srv_addr.sin_addr, ip_str, sizeof(ip_str)), ntohs(srv_addr.sin_port));
                    if (!echo_rqt(connfd, pin)) 
                        break;
                }
                else
                    break;
            } while (1);

            close(connfd);
            printftoflie(fp_res, "[cli](%d) connfd is closed!\n", pid);
            printftoflie(fp_res, "[cli](%d) child process is going to exit!\n", pid);

            fclose(fp_res);
            printf("[cli](%d) stu_cli_res_%d.txt is closed!\n", pid, pin);
            exit(1);
        }
    }

    char fn_res[20];
    sprintf(fn_res, "stu_cli_res_0.txt");
    fp_res = fopen(fn_res, "wb");
    if (!fp_res)
    {
        printf("[cli](%d) child exits, failed to open file \"stu_cli_res_0.txt\"!\n", pid);
        exit(-1);
    }
    printf("[cli](%d) stu_cli_res_0.txt is created!\n", pid);
    printftoflie(fp_res, "[cli](%d) child process 0 is created!\n", pid);


    if ((connfd = socket(PF_INET, SOCK_STREAM, 0)) == -1)
        exit(0);
    do
    {
        int res;
        res = connect(connfd, (struct sockaddr *)&srv_addr, sizeof(srv_addr));
        if (!res)
        {
            char ip_str[20] = {0}; 
            printftoflie(fp_res, "[cli](%d) server[%s:%d] is connected!\n", pid, inet_ntop(AF_INET, &srv_addr.sin_addr, ip_str, sizeof(ip_str)), ntohs(srv_addr.sin_port));
            if (!echo_rqt(connfd, 0)) 
                break;
        }
        else
            break;
    } while (1);

    close(connfd);
    printftoflie(fp_res, "[cli](%d) connfd is closed!\n", pid);
    printftoflie(fp_res, "[cli](%d) child process is going to exit!\n", pid);

    fclose(fp_res);
    printf("[cli](%d) stu_cli_res_0.txt is closed!\n", pid);
    return 0;
}
